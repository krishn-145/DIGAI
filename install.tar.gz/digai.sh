#!/data/data/com.termux/files/usr/bin/bash
# Open GitHub
echo -e "\033[38;5;214m[$current_time]\033[0m \033[1;32m[INFO]:\033[0mInstagram Open..."
am start -a android.intent.action.VIEW -d "https://Instagram.com/ur_.krishn._02" com.android.chrome >/dev/null 2>&1 || {
    echo -e "\033[38;5;214m[$current_time]\033[0m \033[1;33m[WARNING]:\033[0m Could not open ."
}

# ============================================================
#                     DIGAI
#                 AI CODE BUILDER
#                  TERMUX EDITION
# ============================================================

set -u

APP_NAME="digai"
APP_DIR="$HOME/.digai-ai-coder"
PYTHON_FILE="$APP_DIR/digai.py"
ENV_FILE="$HOME/.digai_env"

# ============================================================
# COLORS
# ============================================================

NC='\033[0m'
RED='\033[1;31m'
GREEN='\033[1;32m'
YELLOW='\033[1;33m'
BLUE='\033[1;34m'
MAGENTA='\033[1;35m'
CYAN='\033[1;36m'
WHITE='\033[1;37m'

# ============================================================
# ONE AND ONLY DIGAI BANNER
# ============================================================

banner() {
    clear

    echo -e "${MAGENTA}"

    cat <<'BANNER'
   ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣤⡀
⠀⠀⠀⢀⣶⣦⡀⢀⣀⣤⣴⣶⣶⣿⣿⣶⣶⣤⣤⣀⠀⠀⠀⣠⣾⡿⢹⣇
⠀⠀⠀⢸⡀⢻⣿⣿⠟⠋⠉⠁⠀⠀⠀⠀⠈⠉⠙⠻⢿⣶⢾⣿⠟⠀⢰⡟
⠀⠀⠀⣸⣧⡀⠹⡜⣧⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⡾⣫⡾⠃⠀⣠⡿⠁
⠀⢀⣼⣿⣏⠻⣄⠘⣌⢃⠀⠀⠀⠀⠀⠀⠀⠀⣼⢋⣼⠋⢀⣴⠞⢻⠃⠀
⠀⣼⡿⠁⠙⢦⡘⢷⣌⢞⣆⠀⠀⣀⣀⣠⣄⣾⣷⠟⣡⡾⠋⢀⣴⣿⣧⠀
⢸⣿⠁⠀⠀⠀⠙⠷⣿⣿⣿⠶⢿⣿⣿⣿⣿⣿⣿⢟⣋⣤⣶⠟⠁⠘⣿⡇
⣿⡟⠀⠀⠀⠀⠀⢠⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠁⠀⠀⠀⠀⣿⣧
⣿⣇⠀⠀⠀⠀⠀⣿⣿⣿⡿⠋⢹⡿⠿⢿⣿⣿⣿⡿⢃⣴⠀⠀⠀⠀⣽⣿
⢹⣿⠀⠀⠀⠀⠀⢹⣿⣟⣠⣤⡿⠁⠀⠘⿿⠟⠁⣠⣾⣿⠀⠀⠀⠀⣿⡇
⠘⣿⣆⠀⠀⠀⠀⢸⣿⠋⠉⠀⠀⠀⠀⠀⠸⠿⠿⠿⠿⠏⠀⠀⠀⣸⣿⠁
⠀⠘⣿⣆⠀⠀⠀⠸⠁⠀⠀⠀⠀⠀⠀⠀⢰⣿⣷⣶⠖⠀⠀⠀⣰⣿⠃
⠀⠀⠘⢿⣧⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⠏⠀⠀⣀⣾⡿⠁
⠀⠀⠀⠀⠙⢿⣷⣄⡀⠀⠀⠀⠀⠀⠀⢀⣿⠟⠃⣀⣠⣾⡿⠋
⠀⠀⠀⠀⠀⠀⠉⠛⠿⣷⣶⣦⣤⣤⣤⣬⣴⣶⠾⠛⠁

        [*] </> NAME : DIGAI [✓]
        [*] </> BY   : KRISHN 🔱 [✓]
BANNER

    echo -e "${NC}"
    echo -e "${CYAN}[*] AI   </> NAME : IN DIGAI [✓]${NC}"
    echo -e "${RED}[*] </> BY KRISHN 🚀${NC}"
    echo -e "${BLUE}[*] </> INFO : __.l2l__${NC}"
    echo -e "${GREEN}[*] </> INSTAGRAM : @ur_.krishn._02${NC}"
    echo -e "${YELLOW}[*] </> TELEGRAM  : @krishn18${NC}"
    echo
}

# ============================================================
# CHECK TERMUX
# ============================================================

check_termux() {
    if [ ! -d "/data/data/com.termux" ]; then
        echo -e "${YELLOW}[!] This script is designed for Termux.${NC}"
        echo
    fi
}

# ============================================================
# INSTALL DEPENDENCIES
# ============================================================

install_dependencies() {

    echo -e "${BLUE}[*] Updating Termux packages...${NC}"

    pkg update -y || true

    echo -e "${BLUE}[*] Installing required packages...${NC}"

    pkg install -y \
        python \
        openssl \
        ca-certificates \
        git \
        curl

    echo -e "${BLUE}[*] Installing Python packages...${NC}"

    python -m pip install --upgrade \
        requests \
        urllib3 \
        certifi

    echo
    echo -e "${GREEN}[✓] Dependencies ready.${NC}"
    echo
}

# ============================================================
# API KEY SETUP
# ============================================================

setup_api_key() {

    if [ -f "$ENV_FILE" ]; then
        source "$ENV_FILE"
    fi

    if [ -n "${OPENROUTER_API_KEY:-}" ]; then
        echo -e "${GREEN}[✓] OpenRouter API key already configured.${NC}"
        return 0
    fi

    echo
    echo -e "${YELLOW}OpenRouter API Key Setup${NC}"
    echo
    echo -e "${CYAN}Your API key will not be displayed while typing.${NC}"
    echo

    read -r -s -p "Enter OpenRouter API Key: " API_KEY
    echo

    if [ -z "$API_KEY" ]; then
        echo -e "${RED}[!] API key cannot be empty.${NC}"
        return 1
    fi

    umask 077

    cat > "$ENV_FILE" <<ENV
export OPENROUTER_API_KEY='$API_KEY'
ENV

    chmod 600 "$ENV_FILE"

    export OPENROUTER_API_KEY="$API_KEY"

    echo
    echo -e "${GREEN}[✓] API key saved securely.${NC}"
    echo
}

# ============================================================
# CREATE PYTHON PROGRAM
# ============================================================

create_python_program() {

    mkdir -p "$APP_DIR"

    cat > "$PYTHON_FILE" <<'PYTHON'
#!/usr/bin/env python3

import os
import re
import sys
import json
from pathlib import Path

import requests
import certifi

from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry


# ============================================================
# CONFIG
# ============================================================

API_URL = "https://openrouter.ai/api/v1/chat/completions"

MODEL = "openrouter/free"

TIMEOUT = 300
MAX_RETRIES = 4
MAX_PROJECT_FILES = 100


# ============================================================
# COLORS
# ============================================================

NC = "\033[0m"
RED = "\033[1;31m"
GREEN = "\033[1;32m"
YELLOW = "\033[1;33m"
BLUE = "\033[1;34m"
MAGENTA = "\033[1;35m"
CYAN = "\033[1;36m"


# ============================================================
# SYSTEM PROMPT
# ============================================================

SYSTEM_PROMPT = r"""
You are DIGAI, the DIGAI AI Code Builder.

You are a professional software engineer working inside Termux.

Generate complete software projects based on the user's request.

Supported languages include:

Python
Bash
Java
Kotlin
JavaScript
TypeScript
HTML
CSS
C
C++
PHP
Go
Rust
Ruby
XML
SQL
and other programming languages.

============================================================
STRICT FILE FORMAT
============================================================

Every generated file MUST use:

FILE: filename.ext
complete file contents
END_FILE

Example:

FILE: main.py
print("Hello World")
END_FILE

FILE: README.md
# My Project
END_FILE

Do not use Markdown code fences around FILE blocks.

Do not truncate code.

Do not write:

rest of code
same as above
TODO
implement later

unless the user explicitly asks for a skeleton.

============================================================
PROJECT RULES
============================================================

For larger projects, split the project into multiple files.

Keep all:

- imports
- filenames
- paths
- package names
- dependencies

consistent.

Always create README.md.

README.md should contain:

- Project name
- Description
- Features
- Requirements
- Installation
- Usage
- Project structure
- Configuration
- License

============================================================
INSTALL.SH
============================================================

When a project requires installation, create install.sh.

install.sh must:

- use Bash
- be readable
- install only required dependencies
- be safe to review
- avoid destructive commands
- never delete unrelated user files
- never contain API keys
- never contain passwords
- work with Termux when appropriate

============================================================
DEPENDENCIES
============================================================

For Python projects:

Create requirements.txt when third-party packages are required.

For Node.js projects:

Create package.json when appropriate.

Create .gitignore when useful.

============================================================
SECURITY
============================================================

Never put:

- API keys
- passwords
- tokens
- private credentials

directly into generated source code.

Use environment variables.

============================================================
QUALITY CHECK
============================================================

Before returning the files, internally check:

- syntax
- imports
- references
- paths
- dependencies
- README
- install.sh
- filenames

Return ONLY FILE blocks.
"""


# ============================================================
# ONE AND ONLY DIGAI BANNER
# ============================================================

def show_banner():

    os.system("clear")

    print(MAGENTA)

    print(r"""
   ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣤⡀
⠀⠀⠀⢀⣶⣦⡀⢀⣀⣤⣴⣶⣶⣿⣿⣶⣶⣤⣤⣀⠀⠀⠀⣠⣾⡿⢹⣇
⠀⠀⠀⢸⡀⢻⣿⣿⠟⠋⠉⠁⠀⠀⠀⠀⠈⠉⠙⠻⢿⣶⢾⣿⠟⠀⢰⡟
⠀⠀⠀⣸⣧⡀⠹⡜⣧⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⡾⣫⡾⠃⠀⣠⡿⠁
⠀⢀⣼⣿⣏⠻⣄⠘⣌⢃⠀⠀⠀⠀⠀⠀⠀⠀⣼⢋⣼⠋⢀⣴⠞⢻⠃
⠀⣼⡿⠁⠙⢦⡘⢷⣌⢞⣆⠀⠀⣀⣀⣠⣄⣾⣷⠟⣡⡾⠋⢀⣴⣿⣧⠀
⢸⣿⠁⠀⠀⠀⠙⠷⣿⣿⣿⠶⢿⣿⣿⣿⣿⣿⣿⢟⣋⣤⣶⠟⠁⠘⣿⡇
⣿⡟⠀⠀⠀⠀⠀⢠⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠁⠀⠀⠀⠀⣿⣧
⣿⣇⠀⠀⠀⠀⠀⣿⣿⣿⡿⠋⢹⡿⠿⢿⣿⣿⣿⡿⢃⣴⠀⠀⠀⠀⣽⣿
⢹⣿⠀⠀⠀⠀⠀⢹⣿⣟⣠⣤⡿⠁⠀⠘⠿⠟⠁⣠⣾⣿⠀⠀⠀⠀⣿⡇
⠘⣿⣆⠀⠀⠀⠀⢸⣿⠋⠉⠀⠀⠀⠀⠀⠸⠿⠿⠿⠿⠏⠀⠀⠀⣸⣿⠁
⠀⠘⣿⣆⠀⠀⠀⠸⠁⠀⠀⠀⠀⠀⠀⠀⢰⣿⣷⣶⠖⠀⠀⠀⣰⣿⠃
⠀⠀⠘⢿⣧⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⠏⠀⠀⣀⣾⡿⠁
⠀⠀⠀⠀⠙⢿⣷⣄⡀⠀⠀⠀⠀⠀⠀⢀⣿⠟⠃⣀⣠⣾⡿⠋
⠀⠀⠀⠀⠀⠀⠉⠛⠿⣷⣶⣦⣤⣤⣤⣬⣴⣶⠾⠛⠁

        [*] </> NAME : DIGAI [✓]
        [*] </> BY   : KRISHN 🔱 [✓]
""")

    print(NC)

    print(f"{CYAN}[*] AI   </> NAME : IN DIGAI [✓]{NC}")
    print(f"{RED}[*] </> BY KRISHN 🚀{NC}")
    print(f"{BLUE}[*] </> INFO : __.l2l__{NC}")
    print(f"{GREEN}[*] </> INSTAGRAM : @ur_.krishn._02{NC}")
    print(f"{YELLOW}[*] </> TELEGRAM  : @krishn18{NC}")

    print()


# ============================================================
# REQUEST SESSION
# ============================================================

def create_session():

    session = requests.Session()

    retry = Retry(
        total=MAX_RETRIES,
        connect=MAX_RETRIES,
        read=MAX_RETRIES,
        backoff_factor=1,
        status_forcelist=[
            429,
            500,
            502,
            503,
            504
        ],
        allowed_methods=["POST"],
        raise_on_status=False
    )

    adapter = HTTPAdapter(
        max_retries=retry
    )

    session.mount(
        "https://",
        adapter
    )

    return session


# ============================================================
# ASK AI
# ============================================================

def ask_ai(session, api_key, messages):

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
        "Accept": "application/json",
        "User-Agent": "DIGAI-Code-Builder/1.0"
    }

    payload = {
        "model": MODEL,
        "messages": messages
    }

    try:

        response = session.post(
            API_URL,
            headers=headers,
            json=payload,
            timeout=TIMEOUT,
            verify=certifi.where()
        )

        if response.status_code != 200:

            print()
            print(
                f"{RED}[!] HTTP "
                f"{response.status_code}{NC}"
            )

            try:

                print(
                    json.dumps(
                        response.json(),
                        indent=2,
                        ensure_ascii=False
                    )
                )

            except Exception:

                print(
                    response.text[:3000]
                )

            return None

        data = response.json()

        choices = data.get(
            "choices",
            []
        )

        if not choices:

            print(
                f"{RED}[!] Empty API response.{NC}"
            )

            return None

        message = choices[0].get(
            "message",
            {}
        )

        content = message.get(
            "content"
        )

        if not content:

            print(
                f"{RED}[!] AI returned no content.{NC}"
            )

            return None

        return content

    except requests.exceptions.SSLError as error:

        print(
            f"{RED}[!] SSL/TLS error:{NC}"
        )

        print(error)

        print()

        print(
            "pkg install openssl ca-certificates -y"
        )

        return None

    except requests.exceptions.Timeout:

        print(
            f"{RED}[!] Request timed out.{NC}"
        )

        return None

    except requests.exceptions.ConnectionError as error:

        print(
            f"{RED}[!] Connection error:{NC}"
        )

        print(error)

        return None

    except requests.exceptions.RequestException as error:

        print(
            f"{RED}[!] Request failed:{NC}"
        )

        print(error)

        return None

    except Exception as error:

        print(
            f"{RED}[!] Unexpected error:{NC}"
        )

        print(error)

        return None


# ============================================================
# PARSE FILES
# ============================================================

def parse_files(text):

    pattern = re.compile(
        r"FILE:\s*(.+?)\n"
        r"(.*?)"
        r"END_FILE",
        re.IGNORECASE | re.DOTALL
    )

    results = []

    for filename, content in pattern.findall(text):

        filename = filename.strip()

        if filename:

            results.append(
                (
                    filename,
                    content.rstrip()
                )
            )

    return results


# ============================================================
# SAFE FILENAME
# ============================================================

def safe_filename(filename):

    filename = filename.strip()

    filename = filename.replace(
        "\\",
        "/"
    )

    filename = filename.lstrip("/")

    while "../" in filename:

        filename = filename.replace(
            "../",
            ""
        )

    filename = re.sub(
        r"[^A-Za-z0-9._/\- ]",
        "_",
        filename
    )

    return filename


# ============================================================
# SAFE PROJECT NAME
# ============================================================

def safe_project_name(name):

    name = name.strip()

    name = re.sub(
        r"[^A-Za-z0-9._\- ]",
        "_",
        name
    )

    name = name.replace(
        " ",
        "_"
    )

    return name or "DIGAI_project"


# ============================================================
# SAVE PROJECT
# ============================================================

def save_project(project_name, files):

    project_name = safe_project_name(
        project_name
    )

    root = (
        Path.cwd() /
        project_name
    )

    root.mkdir(
        parents=True,
        exist_ok=True
    )

    saved = []

    for index, item in enumerate(files):

        if index >= MAX_PROJECT_FILES:
            break

        filename, content = item

        filename = safe_filename(
            filename
        )

        if not filename:
            continue

        target = root / filename

        try:

            target.resolve().relative_to(
                root.resolve()
            )

        except ValueError:

            continue

        target.parent.mkdir(
            parents=True,
            exist_ok=True
        )

        # Do not silently overwrite existing files.
        if target.exists():

            backup = target.with_suffix(
                target.suffix + ".bak"
            )

            counter = 1

            while backup.exists():

                backup = target.with_suffix(
                    target.suffix +
                    f".bak{counter}"
                )

                counter += 1

            target = backup

        target.write_text(
            content,
            encoding="utf-8"
        )

        saved.append(
            target.relative_to(root)
        )

        if target.suffix == ".sh":

            try:

                target.chmod(
                    target.stat().st_mode | 0o111
                )

            except Exception:
                pass

    return root, saved


# ============================================================
# SHOW RESULT
# ============================================================

def show_result(root, files):

    print()

    print(
        f"{GREEN}"
        "╔════════════════════════════════════════════╗"
        f"{NC}"
    )

    print(
        f"{GREEN}"
        "║           PROJECT GENERATED               ║"
        f"{NC}"
    )

    print(
        f"{GREEN}"
        "╚════════════════════════════════════════════╝"
        f"{NC}"
    )

    print()

    print(
        f"{CYAN}Location:{NC}"
    )

    print(root)

    print()

    for file in files:

        print(
            f"{GREEN}[✓]{NC} {file}"
        )

    print()

    if (root / "README.md").exists():

        print(
            f"{GREEN}[✓] README.md{NC}"
        )

    if (root / "install.sh").exists():

        print(
            f"{GREEN}[✓] install.sh{NC}"
        )

        print()

        print(
            f"{YELLOW}Review installer first:{NC}"
        )

        print(
            f"cd '{root}'"
        )

        print(
            "cat install.sh"
        )

        print()

        print(
            "bash install.sh"
        )

    print()

    print(
        f"{CYAN}GitHub commands:{NC}"
    )

    print(
        f"cd '{root}'"
    )

    print(
        "git init"
    )

    print(
        "git add ."
    )

    print(
        'git commit -m "Initial project"'
    )

    print()


# ============================================================
# HELP
# ============================================================

def show_help():

    print()

    print(
        f"{CYAN}DIGAI Commands:{NC}"
    )

    print()

    print(
        "/help   - Show help"
    )

    print(
        "/clear  - Clear chat"
    )

    print(
        "/exit   - Exit DIGAI"
    )

    print()

    print(
        f"{CYAN}Examples:{NC}"
    )

    print(
        "Python calculator banao"
    )

    print(
        "Bash backup tool banao"
    )

    print(
        "HTML portfolio website banao"
    )

    print(
        "Java CLI application banao"
    )

    print()


# ============================================================
# MAIN
# ============================================================

def main():

    # ONLY ONE BANNER
    show_banner()

    api_key = os.environ.get(
        "OPENROUTER_API_KEY",
        ""
    ).strip()

    if not api_key:

        print(
            f"{RED}[!] API key not configured.{NC}"
        )

        print(
            "Run: ./digai.sh setup"
        )

        sys.exit(1)

    session = create_session()

    messages = [
        {
            "role": "system",
            "content": SYSTEM_PROMPT
        }
    ]

    print(
        f"{GREEN}[✓] OpenRouter API key detected.{NC}"
    )

    print()

    print(
        f"{CYAN}Commands:{NC}"
    )

    print(
        "/help   Help"
    )

    print(
        "/clear  Clear chat"
    )

    print(
        "/exit   Exit"
    )

    print()

    while True:

        try:

            user_input = input(
                f"\n{BLUE}You > {NC}"
            ).strip()

        except KeyboardInterrupt:

            print()

            continue

        except EOFError:

            print()

            break

        if not user_input:

            continue

        command = user_input.lower()

        if command == "/exit":

            print(
                f"{GREEN}[✓] Goodbye!{NC}"
            )

            break

        if command == "/help":

            show_help()

            continue

        if command == "/clear":

            messages = [
                {
                    "role": "system",
                    "content": SYSTEM_PROMPT
                }
            ]

            # Clear screen and show THE SAME banner.
            show_banner()

            print(
                f"{GREEN}[✓] Chat cleared.{NC}"
            )

            print()

            continue

        messages.append(
            {
                "role": "user",
                "content": user_input
            }
        )

        print()

        print(
            f"{BLUE}"
            "[*] Generating complete project..."
            f"{NC}"
        )

        answer = ask_ai(
            session,
            api_key,
            messages
        )

        if answer is None:

            messages.pop()

            continue

        messages.append(
            {
                "role": "assistant",
                "content": answer
            }
        )

        files = parse_files(
            answer
        )

        if not files:

            print()

            print(
                f"{YELLOW}"
                "[!] AI did not return FILE blocks."
                f"{NC}"
            )

            print()

            print(answer)

            continue

        print()

        try:

            project_name = input(
                f"{YELLOW}"
                "[?] Project name: "
                f"{NC}"
            ).strip()

        except KeyboardInterrupt:

            print()

            continue

        if not project_name:

            project_name = "DIGAI_project"

        root, saved = save_project(
            project_name,
            files
        )

        show_result(
            root,
            saved
        )


# ============================================================
# ENTRY POINT
# ============================================================

if __name__ == "__main__":

    main()

PYTHON

    chmod +x "$PYTHON_FILE"

    echo -e "${GREEN}[✓] DIGAI Python program created.${NC}"
}

# ============================================================
# LOAD ENVIRONMENT
# ============================================================

load_environment() {

    if [ -f "$ENV_FILE" ]; then
        source "$ENV_FILE"
    fi

    export OPENROUTER_API_KEY="${OPENROUTER_API_KEY:-}"
}

# ============================================================
# RUN DIGAI
# ============================================================

dig_app() {

    load_environment

    if [ -z "${OPENROUTER_API_KEY:-}" ]; then

        setup_api_key || exit 1

    fi

    python "$PYTHON_FILE"
}

# ============================================================
# INSTALL APP
# ============================================================

install_app() {

    check_termux

    install_dependencies

    setup_api_key || exit 1

    create_python_program

    echo
    echo -e "${GREEN}╔══════════════════════════════════════════════╗${NC}"
    echo -e "${GREEN}║            DIGAI INSTALL COMPLETE           ║${NC}"
    echo -e "${GREEN}╚══════════════════════════════════════════════╝${NC}"
    echo

    echo -e "${CYAN}Start DIGAI:${NC}"
    echo

    echo "bash $0 dig"

    echo
}

# ============================================================
# COMMAND HANDLER
# ============================================================

case "${1:-install}" in

    install)

        banner

        install_app

        ;;

    dig)

        banner

        load_environment

        if [ ! -f "$PYTHON_FILE" ]; then

            echo -e "${YELLOW}[*] First-time setup...${NC}"

            install_app

        fi

        dig_app

        ;;

    setup)

        setup_api_key

        ;;

    update)

        banner

        install_dependencies

        create_python_program

        echo
        echo -e "${GREEN}[✓] DIGAI updated successfully.${NC}"
        echo

        ;;

    *)

        echo
        echo -e "${CYAN}DIGAI Usage:${NC}"
        echo
        echo "  bash $0 install"
        echo "  bash $0 dig"
        echo "  bash $0 setup"
        echo "  bash $0 update"
        echo -e "${RED}[*] </> INSTAGRAM : @urr_.krishn_02${NC}"
        echo -e "${YELLOW}[*] </> TELEGRAM  : @krishn18${NC}"

        echo
        ;;

esac
